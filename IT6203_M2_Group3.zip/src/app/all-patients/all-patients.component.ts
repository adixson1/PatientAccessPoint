import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-patients',
  templateUrl: './all-patients.component.html',
  styleUrls: ['./all-patients.component.css']
})
export class AllPatientsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
